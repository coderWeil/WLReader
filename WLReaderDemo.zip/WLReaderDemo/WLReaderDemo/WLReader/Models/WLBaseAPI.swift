//
//  WLBaseAPI.swift
//  WLReaderDemo
//
//  Created by 李伟 on 2024/7/16.
//

import Moya

protocol WLBaseAPI: TargetType {}
