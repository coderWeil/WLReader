//
//  WLReadFaultController.swift
//  DuKu
//
//  Created by 李伟 on 2024/6/19.
//  加载或者解析失败的页面

import UIKit

class WLReadFaultController: WLReadBaseController {

    override func updateBackground() {
        view.backgroundColor = .white
    }
}
