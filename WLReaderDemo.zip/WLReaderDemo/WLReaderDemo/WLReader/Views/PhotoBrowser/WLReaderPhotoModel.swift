//
//  WLReaderPhotoModel.swift
//  DuKu
//
//  Created by 李伟 on 2024/6/5.
// 

import UIKit

class WLReaderPhotoModel: NSObject {
    public var image_url:String?
    public var image:UIImage?
}
