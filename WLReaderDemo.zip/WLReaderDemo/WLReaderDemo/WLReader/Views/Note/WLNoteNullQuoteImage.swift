//
//  WLNoteNullQuoteImage.swift
//  DuKu
//
//  Created by 李伟 on 2024/7/7.
//

import UIKit

class WLNoteNullQuoteImage: WLNoteBaseView {
    override func setupConstraints() {
        super.setupConstraints()
    }
}
