//
//  WLNoteTextImageQuoteImage.swift
//  DuKu
//
//  Created by 李伟 on 2024/7/2.
//  引用部分是图片，笔记部分是图片和文本

import UIKit

class WLNoteTextImageQuoteImage: WLNoteBaseView {
    override func setupConstraints() {
        super.setupConstraints()
        
    }
}
