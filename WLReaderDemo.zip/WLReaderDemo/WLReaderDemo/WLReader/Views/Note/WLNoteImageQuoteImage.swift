//
//  WLNoteImageQuoteImage.swift
//  DuKu
//
//  Created by 李伟 on 2024/7/2.
//  引用是图片，笔记是图片

import UIKit

class WLNoteImageQuoteImage: WLNoteBaseView {
    override func setupConstraints() {
        super.setupConstraints()
        
    }
    
}
