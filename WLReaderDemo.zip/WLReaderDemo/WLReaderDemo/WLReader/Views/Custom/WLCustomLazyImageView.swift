//
//  WLCustomLazyImageView.swift
//  DuKu
//
//  Created by 李伟 on 2024/6/29.
//

import DTCoreText

class WLCustomLazyImageView: DTLazyImageView {

   // 图片标识
    public var imageIdentifier:String?

}
